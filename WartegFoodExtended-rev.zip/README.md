# WartegFoodExtended
WartegFoodExtended is a mod for Project Zomboid which adds several Indonesian food recipes.
